#1  
SparseBoundedGrid: using OccupantInCol  

#2  
SparseBoundedGrid2: using hashmap  

#3  
UnboundedGrid2: achieving by doubling the rowNum and the colNum and create a new two-demision array

##SparseGridRunner: run three grid together


